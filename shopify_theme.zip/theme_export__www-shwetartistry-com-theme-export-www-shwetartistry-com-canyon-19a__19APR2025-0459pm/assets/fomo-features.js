document.addEventListener('DOMContentLoaded', () => {
  const viewerCountElement = document.getElementById('viewer-count-number');
  const discountPercentageElement = document.getElementById('discount-percentage');
  const discountTimerElement = document.getElementById('discount-timer');
  const discountCodeElement = document.getElementById('discount-code'); // Get the coupon code element
  const fomoContainer = document.querySelector('.fomo-container'); // Check if the container exists

  // Only run if the FOMO container is present on the page (i.e., on product pages)
  if (fomoContainer && viewerCountElement && discountPercentageElement && discountTimerElement && discountCodeElement) {

    // --- Live Viewer Count ---
    function updateViewerCount() {
      const randomViewers = Math.floor(Math.random() * (50 - 5 + 1)) + 5; // Random number between 5 and 50
      viewerCountElement.textContent = randomViewers;
    }

    // Initial update and set interval
    updateViewerCount();
    setInterval(updateViewerCount, 5000); // Refresh every 5 seconds

    // --- Discount Timer ---
    const discounts = [10, 15, 20, 25];
    let countdownInterval;

    function startDiscountCycle() {
      // Clear any existing interval
      if (countdownInterval) {
        clearInterval(countdownInterval);
      }

      // Determine today's discount
      const today = new Date();
      const dayOfYear = Math.floor((today - new Date(today.getFullYear(), 0, 0)) / (1000 * 60 * 60 * 24));
      const discountIndex = dayOfYear % discounts.length;
      const currentDiscount = discounts[discountIndex];
      discountPercentageElement.textContent = currentDiscount;

      // --- Update Coupon Code Dynamically ---
      const couponCode = `ARTISANSUPPORT${currentDiscount}`;
      discountCodeElement.textContent = couponCode;
      // --- End Update Coupon Code ---

      // Set target time: 24 hours from the start of the current day (midnight)
      const targetTime = new Date(today);
      targetTime.setHours(24, 0, 0, 0); // Set to midnight of the *next* day

      function updateTimer() {
        const now = new Date().getTime();
        const distance = targetTime - now;

        if (distance < 0) {
          // Time's up for today, restart the cycle for the new day
          clearInterval(countdownInterval);
          // Small delay before restarting to ensure date change
          setTimeout(startDiscountCycle, 1000);
          discountTimerElement.textContent = "00:00:00"; // Show expired briefly
          return;
        }

        // Time calculations for hours, minutes and seconds
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

        // Display the result in the element
        discountTimerElement.textContent =
          (hours < 10 ? "0" : "") + hours + ":" +
          (minutes < 10 ? "0" : "") + minutes + ":" +
          (seconds < 10 ? "0" : "") + seconds;
      }

      // Initial timer update and set interval
      updateTimer();
      countdownInterval = setInterval(updateTimer, 1000); // Update every second
    }

    // Start the first cycle
    startDiscountCycle();
  }
});
